##Load Packages

library(ggplot2)
library(haven)

##Read in Data

fgmc <- read_dta("cohorts.dta")

##Fig 3

ggplot(fgmc, aes(BirthYearAge, BirthYearAgeFGMCwtd,colour=CountryName)) + 
  geom_point(color = "black") + 
  geom_line(color = "black") +
  facet_wrap( ~ CountryName) +
  theme(legend.position="none") +
  theme_bw() +
  labs(y = "Percentage of Women Cut", x = "Birth Year")

##Fig 1

kenya <- subset(fgmc, CountryName == "Kenya")

ggplot(kenya, aes(BirthYearAge, BirthYearAgeFGMCwtd,colour=CountryName)) + 
  geom_point(color = "black") + 
  geom_line(color = "black") +
  facet_wrap( ~ CountryName) +
  theme(legend.position="none") +
  theme_bw() +
  labs(y = "Percentage of Women Cut", x = "Birth Year")
