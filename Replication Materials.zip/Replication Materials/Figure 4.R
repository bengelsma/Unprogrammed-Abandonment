##Read in Data

library(readxl)
fgmi <- read_excel("FGMcountries.xlsx")

barplot(height = t(aggregate(decyear~low+mid+high,data=fgmi,FUN=mean)[4]),
        ylim = c(0,.6),
        col = "grey70",
        las = 1,
        names.arg = c("Low (<40%)", "Mid (40-80%)", "High (>80%)"),
        ylab = "Avg. Decline",
        border = "black", axes = TRUE,
        cex.names = .9,
        main = "Initial Prevalence")

barplot(height = t(aggregate(decyear~east+west+central,data=fgmi,FUN=mean)[2:4,4]),
        ylim = c(0, .6),
        col = "grey70",
        las = 1,
        names.arg = c("East Africa", "West Africa", "Central Africa"),
        ylab = "Avg. Decline",
        border = "black", axes = TRUE,
        cex.names = .9,
        main = "Region")

barplot(height = t(aggregate(decyear~london+paris,data=fgmi,FUN=mean)[3]),
        ylim = c(0,.5),
        col = "grey70",
        las = 1,
        names.arg = c("Other", "Ex-British Colony", "Ex-French Colony"),
        ylab = "Avg. Decline",
        border = "black", axes = TRUE,
        cex.names = .9,
        main = "Colonial Power")
